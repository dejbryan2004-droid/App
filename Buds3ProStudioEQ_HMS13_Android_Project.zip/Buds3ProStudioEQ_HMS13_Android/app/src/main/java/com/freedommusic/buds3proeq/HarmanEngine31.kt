package com.freedommusic.buds3proeq

import android.media.audiofx.DynamicsProcessing
import android.util.Log

/**
 * 31-Band ISO Graphic Equalizer Engine using Android DynamicsProcessing API (API 28+)
 * Calibrated for Samsung Galaxy Buds3 Pro -> Harman In-Ear 2019 Target (HMS 1.3)
 */
class HarmanEngine31 {

    companion object {
        val ISO_31_FREQUENCIES = floatArrayOf(
            20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f,
            200f, 250f, 315f, 400f, 500f, 630f, 800f, 1000f, 1250f, 1600f,
            2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f
        )

        // Galaxy Buds3 Pro (ANC On) -> Harman IE 2019 Compensation Curve (HMS 1.3)
        val BUDS3_PRO_HARMAN_2019_GAINS = floatArrayOf(
            1.2f, 1.0f, 0.8f, 0.5f, 0.0f, -0.6f, -1.2f, -1.8f, -2.2f, -2.0f,
            -1.4f, -0.8f, -0.3f, 0.2f, 0.5f, 0.8f, 1.1f, 1.4f, 1.8f, 2.2f,
            2.5f, 2.8f, 3.1f, 2.6f, 1.5f, -0.8f, -1.5f, 0.4f, 1.2f, 1.6f, 1.0f
        )
    }

    private var dynamicsProcessing: DynamicsProcessing? = null
    private var currentSessionId: Int = 0
    private val currentGains = BUDS3_PRO_HARMAN_2019_GAINS.copyOf()
    private var preAmpDb: Float = -3.5f

    fun attachToAudioSession(audioSessionId: Int) {
        release()
        currentSessionId = audioSessionId
        try {
            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2, // Stereo
                true, 31, // Pre-EQ: 31 bands
                true, 4,  // MBC: 4 bands
                true, 31, // Post-EQ: 31 bands
                true      // Limiter enabled to prevent digital clipping
            ).build()

            dynamicsProcessing = DynamicsProcessing(0, audioSessionId, config).apply {
                setInputGainAllChannelsTo(preAmpDb)
                enabled = true
            }
            applyAllBands()
            Log.i("HarmanEngine31", "Attached 31-band DSP to audioSessionId=$audioSessionId")
        } catch (e: Exception) {
            Log.e("HarmanEngine31", "Failed to initialize DynamicsProcessing: ${e.message}")
        }
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        if (bandIndex !in 0..30) return
        val clamped = gainDb.coerceIn(-12.0f, 12.0f)
        currentGains[bandIndex] = clamped

        val dp = dynamicsProcessing ?: return
        val cutoffFreq = ISO_31_FREQUENCIES[bandIndex]
        val eqBand = DynamicsProcessing.EqBand(true, cutoffFreq, clamped)

        for (ch in 0 until 2) {
            dp.setPreEqBandByChannelIndex(ch, bandIndex, eqBand)
        }
    }

    fun setPreAmp(gainDb: Float) {
        preAmpDb = gainDb.coerceIn(-12.0f, 6.0f)
        dynamicsProcessing?.setInputGainAllChannelsTo(preAmpDb)
    }

    fun loadHarman2019Preset() {
        for (i in 0..30) {
            setBandGain(i, BUDS3_PRO_HARMAN_2019_GAINS[i])
        }
        setPreAmp(-3.5f)
    }

    fun resetFlat() {
        for (i in 0..30) {
            setBandGain(i, 0.0f)
        }
        setPreAmp(0.0f)
    }

    fun getBandGains(): FloatArray = currentGains.copyOf()

    private fun applyAllBands() {
        for (i in 0..30) {
            setBandGain(i, currentGains[i])
        }
    }

    fun release() {
        try {
            dynamicsProcessing?.enabled = false
            dynamicsProcessing?.release()
        } catch (_: Exception) {}
        dynamicsProcessing = null
    }
}
