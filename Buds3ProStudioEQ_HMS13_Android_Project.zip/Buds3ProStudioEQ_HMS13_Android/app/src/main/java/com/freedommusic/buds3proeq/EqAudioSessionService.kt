package com.freedommusic.buds3proeq

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class EqAudioSessionService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): EqAudioSessionService = this@EqAudioSessionService
    }

    private val binder = LocalBinder()
    val engine = HarmanEngine31()
    var targetPackageFilter: String? = null
    var activeSessionId: Int = 0

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            val sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)

            if (sessionId == AudioEffect.ERROR || sessionId == 0) return

            if (action == AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION) {
                if (targetPackageFilter == null || targetPackageFilter == pkg) {
                    activeSessionId = sessionId
                    engine.attachToAudioSession(sessionId)
                }
            } else if (action == AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION) {
                if (sessionId == activeSessionId) {
                    engine.release()
                    activeSessionId = 0
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        // Fallback attach to global output mix (session 0) so EQ works immediately
        engine.attachToAudioSession(0)

        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(sessionReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(sessionReceiver, filter)
        }
    }

    private fun startForegroundNotification() {
        val channelId = "buds3_eq_dsp_channel"
        val channel = NotificationChannel(
            channelId,
            "Buds3 Pro 31-Band DSP Engine",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Buds3 Pro Studio EQ • HMS 1.3")
            .setContentText("31-Band Harman In-Ear 2019 DSP Active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        startForeground(101, notification)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        unregisterReceiver(sessionReceiver)
        engine.release()
        super.onDestroy()
    }
}
