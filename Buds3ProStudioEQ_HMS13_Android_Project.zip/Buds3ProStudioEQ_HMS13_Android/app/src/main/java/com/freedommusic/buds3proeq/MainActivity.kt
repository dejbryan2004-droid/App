package com.freedommusic.buds3proeq

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private var eqService: EqAudioSessionService? = null
    private var isBound = false
    private val sliders = mutableListOf<SeekBar>()
    private val valueLabels = mutableListOf<TextView>()

    data class MusicAppTarget(val name: String, val packageName: String?)

    private val playbackApps = listOf(
        MusicAppTarget("Global Output Mix (All Apps)", null),
        MusicAppTarget("Spotify", "com.spotify.music"),
        MusicAppTarget("TIDAL HiFi", "com.aspiro.tidal"),
        MusicAppTarget("YouTube Music", "com.google.android.apps.youtube.music"),
        MusicAppTarget("Apple Music", "com.apple.android.music"),
        MusicAppTarget("Samsung Music", "com.sec.android.app.music"),
        MusicAppTarget("Poweramp", "com.maxmpz.audioplayer")
    )

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as EqAudioSessionService.LocalBinder
            eqService = binder.getService()
            isBound = true
            syncUiFromEngine()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            eqService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val serviceIntent = Intent(this, EqAudioSessionService::class.java)
        startForegroundService(serviceIntent)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)

        buildProgrammaticUi()
    }

    private fun buildProgrammaticUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0E14"))
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "GALAXY BUDS3 PRO • HMS 1.3"
            textSize = 20f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(0, 0, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "31-Band ISO Graphic Equalizer • Harman In-Ear 2019 Target"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(0, 0, 0, 24)
        }
        root.addView(title)
        root.addView(subtitle)

        // Playback App Selector Row
        val appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 24)
        }

        val appSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                playbackApps.map { it.name }
            )
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val launchBtn = Button(this).apply {
            text = "Launch Player"
            setBackgroundColor(Color.parseColor("#0284C7"))
            setTextColor(Color.WHITE)
            setOnClickListener {
                val selected = playbackApps[appSpinner.selectedItemPosition]
                eqService?.targetPackageFilter = selected.packageName
                selected.packageName?.let { pkg ->
                    val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        startActivity(launchIntent)
                    } else {
                        Toast.makeText(this@MainActivity, "${selected.name} not installed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        appRow.addView(appSpinner)
        appRow.addView(launchBtn)
        root.addView(appRow)

        // Preset Buttons
        val presetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 24)
        }
        val harmanBtn = Button(this).apply {
            text = "Harman IE 2019 (HMS 1.3)"
            setOnClickListener {
                eqService?.engine?.loadHarman2019Preset()
                syncUiFromEngine()
            }
        }
        val flatBtn = Button(this).apply {
            text = "Flat (0.0 dB)"
            setOnClickListener {
                eqService?.engine?.resetFlat()
                syncUiFromEngine()
            }
        }
        presetRow.addView(harmanBtn)
        presetRow.addView(flatBtn)
        root.addView(presetRow)

        // Scrollable 31-Band Fader List
        val scrollView = ScrollView(this)
        val bandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        HarmanEngine31.ISO_31_FREQUENCIES.forEachIndexed { index, freq ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 10, 0, 10)
            }

            val freqText = if (freq >= 1000f) {
                String.format(Locale.US, "%.1fk", freq / 1000f).replace(".0k", "k")
            } else {
                String.format(Locale.US, "%.0fHz", freq)
            }

            val label = TextView(this).apply {
                text = freqText
                width = 140
                setTextColor(Color.parseColor("#E2E8F0"))
                textSize = 12f
            }

            val seekBar = SeekBar(this).apply {
                max = 240 // -12.0 dB to +12.0 dB in 0.1 dB increments
                progress = 120
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val valText = TextView(this).apply {
                text = "0.0 dB"
                width = 150
                gravity = Gravity.END
                setTextColor(Color.parseColor("#38BDF8"))
                textSize = 12f
            }

            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val db = (progress - 120) / 10.0f
                    valText.text = String.format(Locale.US, "%+.1f dB", db)
                    if (fromUser) {
                        eqService?.engine?.setBandGain(index, db)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })

            sliders.add(seekBar)
            valueLabels.add(valText)

            row.addView(label)
            row.addView(seekBar)
            row.addView(valText)
            bandContainer.addView(row)
        }

        scrollView.addView(bandContainer)
        root.addView(scrollView)
        setContentView(root)
    }

    private fun syncUiFromEngine() {
        val gains = eqService?.engine?.getBandGains() ?: HarmanEngine31.BUDS3_PRO_HARMAN_2019_GAINS
        gains.forEachIndexed { idx, db ->
            val progress = ((db * 10f) + 120f).toInt().coerceIn(0, 240)
            sliders.getOrNull(idx)?.progress = progress
            valueLabels.getOrNull(idx)?.text = String.format(Locale.US, "%+.1f dB", db)
        }
    }

    override fun onDestroy() {
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        super.onDestroy()
    }
}
