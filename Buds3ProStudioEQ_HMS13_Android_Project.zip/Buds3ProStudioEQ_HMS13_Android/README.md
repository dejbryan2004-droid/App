# Galaxy Buds3 Pro Studio EQ • HMS 1.3 (Harman In-Ear 2019)

Complete 31-band ISO graphic equalizer Android project (`20 Hz` – `20 kHz`) calibrated for the **Samsung Galaxy Buds3 Pro** to match the **Harman In-Ear 2019** target curve, plus ready-to-import 31-band presets for **Wavelet** and **Poweramp Equalizer**.

## Contents
- `app/` — Full Android Studio Kotlin project using Android's `DynamicsProcessing` API (31-band Pre-EQ + Post-EQ + Limiter) and `AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION` app selector/router.
- `presets/Galaxy_Buds3_Pro_Harman_2019_HMS1.3_31Band_Wavelet.txt` — Ready-to-import Wavelet AutoEq file.
- `presets/Galaxy_Buds3_Pro_Harman_2019_HMS1.3_31Band_Poweramp.json` — Ready-to-import Poweramp Equalizer JSON preset.

## How to Build the `.apk` in Android Studio
1. Extract this `.zip` archive.
2. Open **Android Studio** on your MacBook Air and choose **Open** -> select the `Buds3ProStudioEQ_HMS13_Android` folder.
3. Let Gradle sync automatically.
4. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Transfer `app/build/outputs/apk/debug/app-debug.apk` to your Samsung phone and install it.
